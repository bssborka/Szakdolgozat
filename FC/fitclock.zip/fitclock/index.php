<?php
require __DIR__ . '/vendor/autoload.php';

use App\Lib\App;
use App\Lib\Router;
use App\Lib\Request;
use App\Lib\Response;

use App\Controller\LoginController;
use App\Controller\profileController;
use App\Controller\teamsController;
use App\Controller\ratingController;
use App\Controller\statisticsController;

function isProfileLoggedIn(){
    session_start();
    if(!isset($_SESSION['userId']))
    {
        header("Refresh:0; url=/showlogin");
        echo '<script>alert("nincsen bejeletkezett felhasználó.")</script>';
    }
    else{
        return true;
    }
}

/*Szakdolgozat végpontok*/


//belépési pont
Router::get('/', function () {
    return ((new LoginController())->showLogin());
});
Router::get('/showlogin', function () {
    return ((new LoginController())->showLogin());
});
Router::post('/login',function () {
    return ((new LoginController())->login());
});
Router::get('/showRegister', function () {
    return ((new LoginController())->showRegister());
});
Router::post('/registration',function () {
    return ((new LoginController())->registration());
});

//profil adatok
Router::get('/showProfile', function () {
    if(isProfileLoggedIn()){
        return ((new profileController())->showProfile());
        session_destroy();
    }
});

Router::post('/setProfile',function () {
    if(isProfileLoggedIn()){
    return ((new profileController())->setProfile());
    session_destroy();
    }
});

//Felhasználó statisztikái
Router::get('/showUserStatistics', function () {
    if(isProfileLoggedIn()){
        return ((new statisticsController())->showUserStatistics());
        session_destroy();
    }
});



//Értékelés küldése
Router::get('/showRating', function () {
    if(isProfileLoggedIn()){
        return ((new ratingController())->showRating());
        session_destroy();
    }
});

Router::post('/sendRating', function () {
    if(isProfileLoggedIn()){
        return ((new ratingController())->sendRating());
        session_destroy();
    }
});

//csapatok
Router::get('/showTeams', function () {
    if(isProfileLoggedIn()){
        return ((new teamsController())->showTeams());
        session_destroy();
    }
});

Router::post('/showCreateTeam', function () {
    if(isProfileLoggedIn()){
        return ((new teamsController())->showCreateTeam());
        session_destroy();
    }
});

Router::post('/createTeam',function () {
    if(isProfileLoggedIn()){
    return ((new teamsController())->createTeam());
    session_destroy();
    }
});

Router::get('/loadTeam/([0-9]*)', function (Request $req, Response $res) {
    if(isProfileLoggedIn()){
       return (new teamsController())->loadTeam($req->params[0]);
        
      session_destroy();
    }
});

Router::post('/loadTeam/inviteMember',function () {
    if(isProfileLoggedIn()){
    return ((new teamsController())->inviteUserToTeam());
    session_destroy();
    }
});

Router::get('/memberDelete/([0-9]*)', function (Request $req, Response $res) {
    if(isProfileLoggedIn()){
       return (new teamsController())->memberDelete($req->params[0]);
        
      session_destroy();
    }
});