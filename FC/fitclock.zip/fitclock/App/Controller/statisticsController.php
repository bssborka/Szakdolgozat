<?php namespace App\Controller;

use App\Model\statisticsDAO;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class statisticsController implements statisticsCrud
{
    public function setTwigEnvironment()
    {
        $loader = new FilesystemLoader(__DIR__ . '\..\View');
        $twig = new \Twig\Environment($loader, [
            'debug' => true,
        ]);
        $twig->addExtension(new \Twig\Extension\DebugExtension()); 
        return $twig;
    }

    public function showUserStatistics()
    {
            $twig = (new statisticsController())->setTwigEnvironment(); 
            $thisWeeksWorkoutData= statisticsDAO::getUserWorkoutsOnTheWeek();
            $exercisesData=statisticsDAO::getExercisesData();
            $muscleGroupsData = statisticsDAO::getMusclegroupsData();

            $userProfilePicture = statisticsDAO::getProfilePicture($_SESSION['profPicId']);
            $userData = (object) array('username'=>$_SESSION['userName']);

            $calories= (new statisticsController())->calculateCaloriesForTheWeek($thisWeeksWorkoutData,$exercisesData);
            $times = (new statisticsController())->calculateWorkTimeForTheWeek($thisWeeksWorkoutData); 
            $intensities = (new statisticsController())->calculateIntensityForTheWeek($thisWeeksWorkoutData,$exercisesData);
            $muscleUsage = (new statisticsController())->calculateMuscleGroupUsageForTheWeek($thisWeeksWorkoutData,$exercisesData,$muscleGroupsData); 

            echo $twig->render('statistics/userStatistics.html.twig', ['userData'=>$userData,'profPic'=>$userProfilePicture,'caloriesOfWeek'=>$calories,'timesOfWeek'=>$times,'intensitiesOfWeek'=>$intensities,'muscleUsageOfWeek'=>$muscleUsage,"muscleGroupsData"=>$muscleGroupsData]);
    }


    public function calculateCaloriesForTheWeek($workouts,$exercises)
    {
        $workoutNumber=statisticsDAO::getNumberOfUserWorkoutsOnTheWeek();
        $exerciseNumber=statisticsDAO::getNumberOfExercisesData();

        $finalCalories = [0,0,0,0,0,0,0]; //0-vasárnap 1-hétfő 2-kedd ... 6-szombat
       
        for($i=0; $i<$workoutNumber;$i++)             //objectum első sorának felbonbtása
        { 
            $timestamp = strtotime($workouts[$i]->dateOfExercise);
            $dayOfWorkout = date('w', $timestamp);      //melyik nap volt az exercise 0-6 közötti szám

            $calorie = 0;
            $oneWorkout = explode(",", $workouts[$i]->exerciseList);
            $oneWorkoutTimes = explode(",", $workouts[$i]->exerciseTimeList);

            for($y=0; $y<count($oneWorkout)-1;$y++){      //1db workout 

                for($x=0; $x<$exerciseNumber;$x++)    //exercise id+caloriesPerSec megkeresése
                {
                    if($oneWorkout[$y]==$exercises[$x]->exerciseId)
                    {
                        $calorie= $calorie + ($oneWorkoutTimes[$y] * $exercises[$x]->caloriesPerSec);  
                       
                    }
                }

            }

            for($day=0;$day<6;$day++){
                if($dayOfWorkout==$day){
                    $finalCalories[$day]=$finalCalories[$day]+$calorie;
                }
            }
           
        }
       
        return $finalCalories;
    }

    public function calculateWorkTimeForTheWeek($workouts)
    {
        $workoutNumber=statisticsDAO::getNumberOfUserWorkoutsOnTheWeek();

        $finalWorkoutTimes = [0,0,0,0,0,0,0]; //0-vasárnap 1-hétfő 2-kedd ... 6-szombat
       
        for($i=0; $i<$workoutNumber;$i++)             //objectum első sorának felbonbtása
        { 
            $timestamp = strtotime($workouts[$i]->dateOfExercise);
            $dayOfWorkout = date('w', $timestamp);      //melyik nap volt az exercise 0-6 közötti szám

            $time = 0;
            $oneWorkoutTimes = explode(",", $workouts[$i]->exerciseTimeList);

            for($y=0; $y<count($oneWorkoutTimes)-1;$y++)  //1db workout ideje
            {      
                $time= $time + intval($oneWorkoutTimes[$y]);  
            }

            for($day=0;$day<6;$day++){
                if($dayOfWorkout==$day){
                    $finalWorkoutTimes[$day]=$finalWorkoutTimes[$day]+$time;
                }
            }
           
        }
       
        return $finalWorkoutTimes;
    }

    public function calculateIntensityForTheWeek($workouts,$exercises)
    {
        $workoutNumber=statisticsDAO::getNumberOfUserWorkoutsOnTheWeek();
        $exerciseNumber=statisticsDAO::getNumberOfExercisesData();
        
        $finalIntensities = [0,0,0,0,0,0,0]; //0-vasárnap 1-hétfő 2-kedd ... 6-szombat

        $intensitiesSUM = [0,0,0,0,0,0,0];  //egy napon lévő intenzitások összege
        $intensitiesNUM = [0,0,0,0,0,0,0];  //egy napon lévő intenzitások száma

        for($i=0; $i<$workoutNumber;$i++)             //objectum első sorának felbonbtása
        { 
            $timestamp = strtotime($workouts[$i]->dateOfExercise);
            $dayOfWorkout = date('w', $timestamp);      //melyik nap volt az exercise 0-6 közötti szám

            $intensity = [0,0];     //0 index = intenzitások összessége 1 index= intenzitások darabszáma
            $oneWorkout = explode(",", $workouts[$i]->exerciseList);

            for($y=0; $y<count($oneWorkout)-1;$y++){      //1db workout 

                for($x=0; $x<$exerciseNumber;$x++)    
                {
                    if($oneWorkout[$y]==$exercises[$x]->exerciseId)
                    {
                        $intensity[0]=$intensity[0] + $exercises[$x]->exerciseIntensity;
                    }
                }
                $intensity[1]=count($oneWorkout)-1;
            }

            for($day=0;$day<6;$day++){
                if($dayOfWorkout==$day){
                    $intensitiesSUM[$day]=$intensitiesSUM[$day]+$intensity[0];
                    $intensitiesNUM[$day]=$intensitiesNUM[$day]+$intensity[1];
                }
            }
           
        }
        
        for($i=0; $i<count($finalIntensities);$i++){
           
            if($intensitiesNUM[$i]!=0){
                $finalIntensities[$i] = $intensitiesSUM[$i] / $intensitiesNUM[$i];  //egy napon lévő intenzitások átlaga
            }
        }

        return $finalIntensities;
    }

    public function calculateMuscleGroupUsageForTheWeek($workouts,$exercises,$muscles)
    {
        $workoutNumber=statisticsDAO::getNumberOfUserWorkoutsOnTheWeek();
        $exerciseNumber=statisticsDAO::getNumberOfExercisesData();
        $muscleGroupsNumber = statisticsDAO::getNumberOfMusclegroupsData();

        $finalMuscleUsage = []; 
        for($m=0; $m<$muscleGroupsNumber;$m++){
            array_push($finalMuscleUsage,0);
        }
       
        for($i=0; $i<$workoutNumber;$i++)             //objectum első sorának felbonbtása
        { 
            $oneWorkout = explode(",", $workouts[$i]->exerciseList);
            $oneWorkoutTimes = explode(",", $workouts[$i]->exerciseTimeList);

            for($y=0; $y<count($oneWorkout)-1;$y++){      //1db workout 

                for($x=0; $x<$exerciseNumber;$x++)    
                {
                    if($oneWorkout[$y]==$exercises[$x]->exerciseId)
                    {
                        $exerciseInvolvedMuscles = explode(";", $exercises[$x]->muscleGroupId);

                        for($m=0; $m<count($exerciseInvolvedMuscles);$m++){
                            $index=intval($exerciseInvolvedMuscles[$m])-1;
                            $finalMuscleUsage[$index]= $finalMuscleUsage[$index] + intval($oneWorkoutTimes[$y]);
                        }
                       
                    }
                }

            }
        }
       
        return $finalMuscleUsage;
    }
}