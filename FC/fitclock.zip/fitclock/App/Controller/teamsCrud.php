<?php namespace App\Controller;

    interface teamsCrud
    {
        public function setTwigEnvironment();
        public function showTeams();
        public function showCreateTeam();
        public function createTeam();
        public function isItCorrectImage(string $imageType);
        public function compress_image($source_file, $destination, $quality, $w, $h ,$crop);
        public function loadTeam(int $teamId);
        public function getUserType($oneTeam);
        public function inviteUserToTeam();
        public function memberDelete(int $userId);
    }
?>