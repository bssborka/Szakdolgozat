<?php namespace App\Controller;

use App\Model\profileDAO;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class profileController implements profileCrud
{
    public function setTwigEnvironment()
    {
        $loader = new FilesystemLoader(__DIR__ . '\..\View');
        $twig = new \Twig\Environment($loader, [
            'debug' => true,
        ]);
        $twig->addExtension(new \Twig\Extension\DebugExtension()); 
        return $twig;
    }

    public function showProfile()
    {
            $twig = (new profileController())->setTwigEnvironment(); 
            $userData = profileDAO::getProfileData();
            $userProfilePicture = profileDAO::getProfilePicture($_SESSION['profPicId']);

            echo $twig->render('profile/profile.html.twig', ['userData'=>$userData,'profPic'=>$userProfilePicture]);
    }

    public function setProfile()
    {
        
        $userName=$_POST['userName'];
        $userPassword=$_POST['userPassword'];
        $userPasswordSecond=$_POST['userPasswordSecond'];
        $userBirthDate=$_POST['userBirthDate'];
        $userWeight=$_POST['userWeight'];
        $userHeight=$_POST['userHeight'];
       

        if($userPassword==$userPasswordSecond && $userPassword!=NULL){

            if(is_uploaded_file($_FILES['userProfilePic']['tmp_name'])){
                $myimage = $_FILES['userProfilePic']['tmp_name'];
                $myimageType = $_FILES['userProfilePic']['type'];
    
                $askImageType = (new profileController())->isItCorrectImage($myimageType); 
                if($askImageType)
                {
                    $newImage= "newProfPic.jpg";
                    $compressedImage = (new profileController())->compress_image($myimage,$newImage, 70, 200,200);
                    $letstry = base64_encode(file_get_contents(addslashes($compressedImage)));
                    profileDAO::setProfileDataWithPofilePictureAndPassword($letstry, $userName, $userPassword, $userBirthDate, $userWeight, $userHeight);
                  
                    header("Refresh:0; url=/showProfile");
                    echo '<script>alert("Sikeresen megváltoztatta az adatait.")</script>';
                }
                else{
                    header("Refresh:0; url=/showProfile");
                    echo '<script>alert("Nem megfelelő kép formátum")</script>';
                }
            }else{
                profileDAO::setProfileData($userName, $userPassword, $userBirthDate, $userWeight, $userHeight);
           
                header("Refresh:0; url=/showProfile");
                echo '<script>alert("Sikeresen megváltoztatta az adatait.")</script>';
            }
        }
        elseif($userPassword!=$userPasswordSecond && $userPassword!=NULL){
            echo '<script>alert("A jelszavak nem egyeznek.")</script>';
            header("Refresh:0; url=/showProfile");
        }
        else{

            if(is_uploaded_file($_FILES['userProfilePic']['tmp_name'])){
                $myimage = $_FILES['userProfilePic']['tmp_name'];
                $myimageType = $_FILES['userProfilePic']['type'];
    
                $askImageType = (new profileController())->isItCorrectImage($myimageType); 
                if($askImageType)
                {
                    $newImage= "newProfPic.jpg";
                    $compressedImage = (new profileController())->compress_image($myimage,$newImage, 70, 200,200);
                    $letstry = base64_encode(file_get_contents(addslashes($compressedImage)));
                    profileDAO::setProfileDataWithPofilePicture($letstry, $userName, $userBirthDate, $userWeight, $userHeight);
                  
                    header("Refresh:0; url=/showProfile");
                    echo '<script>alert("Sikeresen megváltoztatta az adatait.")</script>';
                }
                else{
                    header("Refresh:0; url=/showProfile");
                    echo '<script>alert("Nem megfelelő kép formátum")</script>';
                }
            }else{
                profileDAO::setProfileDataWithoutNewPassword( $userName, $userBirthDate, $userWeight, $userHeight);
                header("Refresh:0; url=/showProfile");
                echo '<script>alert("Sikeresen megváltoztatta az adatait.")</script>';
            }
        }
    }


    public function isItCorrectImage(string $imageType) {
        $allowedTypes = array('image/png','image/jpeg', 'image/jpg');
        if (in_array($imageType, $allowedTypes)) 
        {
          return true;
        } 
        else 
        {
          return false;
        }
    }
    public function compress_image($source_file, $destination, $quality, $w, $h ,$crop=TRUE) {
        //eredeti kép szélessége/magassága/arányának lekérése, és új szélesség/magasság generálása
         list($width, $height, $type) = getimagesize($source_file);
         $r = $width / $height;
         if ($crop) {
             if ($width > $height) {
                 $width = ceil($width-($width*abs($r-$w/$h)));
             } else {
                 $height = ceil($height-($height*abs($r-$w/$h)));
             }
             $newwidth = $w;
             $newheight = $h;
         } else {
             if ($w/$h > $r) {
                 $newwidth = $h*$r;
                 $newheight = $h;
             } else {
                 $newheight = $w/$r;
                 $newwidth = $w;
             }
         }
             //Esetleges elfordulás esetén, álló helyzetbe forgatás
             $info = getimagesize($source_file);
             if ($info['mime'] == 'image/jpeg'){
                 $image = imagecreatefromjpeg($source_file);
                 $exif = @exif_read_data($source_file);
                 if($exif && isset($exif['Orientation'])) {
                     $orientation = $exif['Orientation'];
                     if($orientation != 1){
                         $deg = 0;
                         switch ($orientation) {
                             case 3:
                                 $deg = 180;
                                 break;
                             case 6:
                                 $deg = 270;
                                 break;
                             case 8:
                                 $deg = 90;
                                 break;
                         }
                         if ($deg) {
                             $image = imagerotate($image, $deg, 0);
                         }
                     }
                 }
             }
             elseif($info['mime'] == 'image/png'){
                 $image = imagecreatefrompng($source_file);
             }
 
         //Méretre vágás, minőség csökkentés, új kép készítés
         $dst = imagecreatetruecolor($newwidth, $newheight);
         imagecopyresampled($dst, $image, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
        
         imagejpeg($dst, $destination, $quality);
 
         return $destination;
        
         //memória felszabadítása
         imagedestroy($image);
         imagedestroy($dst);
         imagedestroy($destination);
     }
}