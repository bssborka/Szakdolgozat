<?php namespace App\Controller;

    interface InterfaceCrud
    {
        public function setTwigEnvironment();
        public function showLogin();
        public function login();
        public function showRegister();
        public function registration();
    }
?>