<?php namespace App\Controller;

use App\Model\ratingDAO;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class ratingController implements ratingCrud
{
    public function setTwigEnvironment()
    {
        $loader = new FilesystemLoader(__DIR__ . '\..\View');
        $twig = new \Twig\Environment($loader, [
            'debug' => true,
        ]);
        $twig->addExtension(new \Twig\Extension\DebugExtension()); 
        return $twig;
    }

    public function showRating()
    {
            $twig = (new ratingController())->setTwigEnvironment(); 

            $didSendData = ratingDAO::decideIfAlreadySent();
            
            if($didSendData!=NULL){
                $allowRating=FALSE;
                echo '<script>alert("Már egyszer elküdted nekünk a véleményed.")</script>';
            }
            else{
                $allowRating=TRUE;
            }
            $userProfilePicture = ratingDAO::getProfilePicture($_SESSION['profPicId']);
            $userData = (object) array('username'=>$_SESSION['userName']);
            echo $twig->render('rating/rating.html.twig', ['userData'=>$userData, 'allowRating'=>$allowRating,'profPic'=>$userProfilePicture]);
    }

    public function sendRating()
    {
            $graphics=$_POST['graphics'];
            $functions=$_POST['functions'];
            $exercises=$_POST['exercises'];
            $groups=$_POST['groups'];
            $comments=$_POST['comment'];

            ratingDAO::setRating($graphics, $functions, $exercises, $groups, $comments);

            header("Refresh:0; url=/showRating");
            echo '<script>alert("Köszönjük szépen a visszajelzését.")</script>';
            
    }

}