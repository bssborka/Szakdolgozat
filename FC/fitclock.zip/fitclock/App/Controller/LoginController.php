<?php namespace App\Controller;

use App\Model\loginDAO;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class LoginController implements InterfaceCrud
{
    public function setTwigEnvironment()
    {
        $loader = new FilesystemLoader(__DIR__ . '\..\View');
        $twig = new \Twig\Environment($loader, [
            'debug' => true,
        ]);
       
        $twig->addExtension(new \Twig\Extension\DebugExtension()); 
        return $twig;
    }

    public function showLogin()
    {
        session_start();
        $_SESSION = array();
       
        $twig = (new LoginController())->setTwigEnvironment(); 
        echo $twig->render('login/login.html.twig', []);
    }

    public function login(){
        $userEmail= $_POST['userEmail'];
        $password=$_POST['password'];

        $userData = loginDAO::getUser($userEmail, $password);
        $twig = (new LoginController())->setTwigEnvironment();

       
        if($userData!=NULL){
            $id=$userData->userId;
            $picId=$userData->profilePicId;
            $userName=$userData->username;
            
            session_start();
            $_SESSION['userId']=$id;
            $_SESSION['userName']=$userName;
            $_SESSION['profPicId']=$picId;

            $userProfilePicture = loginDAO::getProfilePicture($picId);

            echo $twig->render('statistics/userStatistics.html.twig', ['userData'=>$userData,'profPic'=>$userProfilePicture]);
            
        }
        else{
            echo '<script>alert("Hibás felhasználónév vagy jelszó.")</script>';
            header("Refresh:0; url=/showlogin");
        }
       
    }

    //Registration
    public function showRegister()
    {
        $twig = (new LoginController())->setTwigEnvironment(); 
        echo $twig->render('login/registration.html.twig', []);
       
    }

    public function registration(){
        $userEmail=$_POST['userEmail'];
        $userName=$_POST['userName'];
        $userPassword=$_POST['userPassword'];
        $userPasswordSecond=$_POST['userPasswordSecond'];
        $userBirthDate=$_POST['userBirthDate'];
        $userSex=$_POST['userSex'];

       
        if(loginDAO::userIsRegistered($userEmail)){
                echo '<script>alert("Ezzel az emaillel már regisztrált felhasználó.")</script>';
                header("Refresh:0; url=/showlogin");
        }else{
            if($userPassword!=$userPasswordSecond){
                echo '<script>alert("A jelszavak nem egyeznek.")</script>';
                header("Refresh:0; url=/showRegister");
            }
            else{
                loginDAO::createUser($userEmail, $userName, $userPassword, $userBirthDate, $userSex);
               
                header("Refresh:0; url=/showlogin");
                echo '<script>alert("Sikeres regisztáció.")</script>';
            }
        }
    }
}