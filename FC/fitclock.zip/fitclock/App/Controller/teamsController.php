<?php namespace App\Controller;

use App\Model\teamsDAO;
use Twig\Environment;
use Twig\Loader\FilesystemLoader;

class teamsController implements teamsCrud
{
    public function setTwigEnvironment()
    {
        $loader = new FilesystemLoader(__DIR__ . '\..\View');
        $twig = new \Twig\Environment($loader, [
            'debug' => true,
        ]);
        $twig->addExtension(new \Twig\Extension\DebugExtension()); 
        return $twig;
    }

    public function showTeams()
    {
            $twig = (new teamsController())->setTwigEnvironment(); 
            $teamsData = teamsDAO::getTeams();

            $userProfilePicture = teamsDAO::getProfilePicture($_SESSION['profPicId']);
            $userData = (object) array('username'=>$_SESSION['userName']);
            echo $twig->render('teams/teams.html.twig', ['userData'=>$userData, 'teams'=>$teamsData,'profPic'=>$userProfilePicture]);
    }

    public function showCreateTeam()
    {
            $twig = (new teamsController())->setTwigEnvironment(); 
            
            $userProfilePicture = teamsDAO::getProfilePicture($_SESSION['profPicId']);
            $userData = (object) array('username'=>$_SESSION['userName']);
            echo $twig->render('teams/createTeam.html.twig', ['userData'=>$userData,'profPic'=>$userProfilePicture]);
    }
    
    public function createTeam()
    {
        $myimage = $_FILES['teamProfilePic']['tmp_name'];
        $myimageType = $_FILES['teamProfilePic']['type'];
        $teamName=$_POST['teamName'];

        $askImageType = (new teamsController())->isItCorrectImage($myimageType); 
        if($askImageType)
        {
            $newImage= "newpic.jpg";
            $compressedImage = (new teamsController())->compress_image($myimage,$newImage, 70, 100,100);
            $letstry = base64_encode(file_get_contents(addslashes($compressedImage)));
            teamsDAO::createTeam($teamName,$letstry);
          
            header("Refresh:0; url=/showTeams");
            echo '<script>alert("A csapat sikeres létrehozása.")</script>';
        }
        else{
            header("Refresh:0; url=/showTeams");
            echo '<script>alert("Nem megfelelő kép formátum")</script>';
        }
        
    }

    public function isItCorrectImage(string $imageType) {
        $allowedTypes = array('image/png','image/jpeg', 'image/jpg');
        if (in_array($imageType, $allowedTypes)) 
        {
          return true;
        } 
        else 
        {
          return false;
        }
    }


    public function compress_image($source_file, $destination, $quality, $w, $h ,$crop=TRUE) {
       //https://www.php.net/manual/en/function.imagecopyresized.php
       //resize before upload and quality change

       //https://www.php.net/manual/en/function.getimagesize.php
       //https://www.php.net/manual/en/function.imagejpeg.php

       //Get source with/height/ratio and generate new  width/height depending on CROPPING
        list($width, $height, $type) = getimagesize($source_file);
        $r = $width / $height;
        if ($crop) {
            if ($width > $height) {
                $width = ceil($width-($width*abs($r-$w/$h)));
            } else {
                $height = ceil($height-($height*abs($r-$w/$h)));
            }
            $newwidth = $w;
            $newheight = $h;
        } else {
            if ($w/$h > $r) {
                $newwidth = $h*$r;
                $newheight = $h;
            } else {
                $newheight = $w/$r;
                $newwidth = $w;
            }
        }
            //Rotate to normal
            $info = getimagesize($source_file);
            if ($info['mime'] == 'image/jpeg'){
                $image = imagecreatefromjpeg($source_file);
                $exif = @exif_read_data($source_file);
                if($exif && isset($exif['Orientation'])) {
                    $orientation = $exif['Orientation'];
                    if($orientation != 1){
                        $deg = 0;
                        switch ($orientation) {
                            case 3:
                                $deg = 180;
                                break;
                            case 6:
                                $deg = 270;
                                break;
                            case 8:
                                $deg = 90;
                                break;
                        }
                        if ($deg) {
                            $image = imagerotate($image, $deg, 0);
                        }
                    }
                }
            }
            elseif($info['mime'] == 'image/png'){
                $image = imagecreatefrompng($source_file);
            }

        //CROP and decrease quality, then create new image
        $dst = imagecreatetruecolor($newwidth, $newheight);
        imagecopyresampled($dst, $image, 0, 0, 0, 0, $newwidth, $newheight, $width, $height);
       
        imagejpeg($dst, $destination, $quality);

        return $destination;
       
        //release memory slots
        imagedestroy($image);
        imagedestroy($dst);
        imagedestroy($destination);
    }

    public function loadTeam(int $teamId){
        $twig = (new teamsController())->setTwigEnvironment(); 
        $oneTeam = teamsDAO::getOneTeam($teamId);

        $userType= (new teamsController())->getUserType($oneTeam);

        $userProfilePicture = teamsDAO::getProfilePicture($_SESSION['profPicId']);
        $userData = (object) array('username'=>$_SESSION['userName']);

        $teamData = (object) array('teamId'=>$teamId);
        $membersData = teamsDAO::getTeamMembers($teamId);
        $teamName = teamsDAO::getTeamName($teamId);

        if($userType=="admin"){
            $_SESSION['groupId']=$teamId;
            echo '<script>alert("admin belepes")</script>';
            echo $twig->render('teams/adminTeam.html.twig', ['userData'=>$userData,'teamData'=>$teamData,'members'=>$membersData, 'teamName'=>$teamName,'profPic'=>$userProfilePicture]);
           
        }elseif($userType=="simpleUser"){
            $_SESSION['groupId']=$teamId;
            echo '<script>alert("simpleUser belepes")</script>';
            echo $twig->render('teams/userTeam.html.twig', ['userData'=>$userData,'profPic'=>$userProfilePicture,'members'=>$membersData]);

        }elseif($userType=="notUser"){
            header("Refresh:0; url=/showTeams");
            echo '<script>alert("Nem vagy tagja a csapatnak")</script>';
        }
    }

    public function getUserType($oneTeam){
        foreach($oneTeam as $user){
            if($user->groupAdmin==$_SESSION['userId']){
                return "admin";
            }
            elseif($user->userId==$_SESSION['userId']){
                return "simpleUser";
            }
        };
        return "notUser";
    }

    public function inviteUserToTeam(){
        $teamUsersEmails=$_POST['teamUsersEmails'];
        if($teamUsersEmails == NULL){
            header("Refresh:0; url=/loadTeam/".$_SESSION['groupId']);
            echo '<script>alert("Nem adott meg email címet.")</script>';
        }
        else{
            teamsDAO::inviteUsers($teamUsersEmails,  $_SESSION['groupId']);
            
            header("Refresh:0; url=/loadTeam/".$_SESSION['groupId']);
            echo '<script>alert("Tagok felvéve.")</script>';
        }
       
    }

    public function memberDelete(int $userId){
        teamsDAO::memberDelete($userId,$_SESSION['groupId']);

        header("Refresh:0; url=/loadTeam/".$_SESSION['groupId']);
        echo '<script>alert("A csapattag törlése megtörtént")</script>';
    }

}