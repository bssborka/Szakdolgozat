<?php namespace App\Controller;

    interface profileCrud
    {
        public function setTwigEnvironment();
        public function showProfile();
        public function setProfile();
        public function isItCorrectImage(string $imageType);
        public function compress_image($source_file, $destination, $quality, $w, $h ,$crop);
    }
?>