<?php namespace App\Controller;

    interface ratingCrud
    {
        public function setTwigEnvironment();
        public function showRating();
        public function sendRating();
        
    }
?>