<?php namespace App\Controller;

    interface statisticsCrud
    {
        public function setTwigEnvironment();
        public function showUserStatistics();
        public function calculateCaloriesForTheWeek($workouts,$exercises);
        public function calculateWorkTimeForTheWeek($workouts);
        public function calculateIntensityForTheWeek($workouts,$exercises);
        public function calculateMuscleGroupUsageForTheWeek($workouts,$exercises,$muscles);
    }
?>