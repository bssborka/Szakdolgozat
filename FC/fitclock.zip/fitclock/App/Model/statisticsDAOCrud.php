<?php namespace App\Model;

    interface statisticsDAOCrud
    {
        public static function getProfileData();
        public static function getProfilePicture(int $picId);
        public static function getUserWorkoutsOnTheWeek();
        public static function getExercisesData();
        public static function getMusclegroupsData();
        public static function getNumberOfMusclegroupsData();
        public static function getNumberOfUserWorkoutsOnTheWeek();
        public static function getNumberOfExercisesData();
    }
?>