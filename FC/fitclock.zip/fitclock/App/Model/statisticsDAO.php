<?php namespace App\Model;

use App\Lib\Database;
use App\Model\statisticsDAOCrud;

class statisticsDAO implements statisticsDAOCrud
{
    public static function getProfileData(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
        
        $statement=$conn->prepare("SELECT * FROM users WHERE userId=:userId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'userId'=>$_SESSION['userId'],
        ]);
        return $statement->fetch();
    }

    public static function getProfilePicture(int $picId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("SELECT picture FROM userprofilepic WHERE picId=:picId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'picId'=>$picId,
        ]);

        return $statement->fetch();
    }

    public static function getUserWorkoutsOnTheWeek(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
        
        $statement=$conn->prepare("SELECT workout.dateOfExercise, workout.exerciseList, workout.exerciseTimeList FROM workout WHERE workout.userId=:userId AND workout.dateOfExercise BETWEEN (SELECT DATE_ADD(CURDATE(), INTERVAL - WEEKDAY(CURDATE()) DAY)) AND (SELECT DATE_ADD(CURDATE(), INTERVAL 6 - WEEKDAY(CURDATE()) DAY));");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'userId'=>$_SESSION['userId'],
        ]);
        return $statement->fetchAll();
    }

    public static function getExercisesData(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
      
        $statement=$conn->prepare("SELECT exercise.exerciseId, exercise.caloriesPerSec, exercise.exerciseIntensity, exercise.muscleGroupId FROM exercise;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([]);
        return $statement->fetchAll();
    }

    public static function getMusclegroupsData(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
      
        $statement=$conn->prepare("SELECT muscles.musclesId, muscles.muscleGroupName FROM muscles;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([]);
        return $statement->fetchAll();
    }
    public static function getNumberOfMusclegroupsData(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
      
        $statement=$conn->prepare("SELECT muscles.musclesId, muscles.muscleGroupName FROM muscles;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([]);
        return $statement->rowCount();
    }

    public static function getNumberOfUserWorkoutsOnTheWeek(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
        
        $statement=$conn->prepare("SELECT workout.dateOfExercise, workout.exerciseList, workout.exerciseTimeList FROM workout WHERE workout.userId=:userId AND workout.dateOfExercise BETWEEN (SELECT DATE_ADD(CURDATE(), INTERVAL - WEEKDAY(CURDATE()) DAY)) AND (SELECT DATE_ADD(CURDATE(), INTERVAL 6 - WEEKDAY(CURDATE()) DAY));");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'userId'=>$_SESSION['userId'],
        ]);
        return $statement->rowCount();
    }
    
    public static function getNumberOfExercisesData(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
      
        $statement=$conn->prepare("SELECT exercise.exerciseId, exercise.caloriesPerSec, exercise.exerciseIntensity, exercise.muscleGroupId FROM exercise;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([]);
        return $statement->rowCount();
    }
}