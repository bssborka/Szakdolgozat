<?php namespace App\Model;

use App\Lib\Database;
use App\Model\profileDAOCrud;

class profileDAO implements profileDAOCrud
{
    
    public static function getProfilePicture(int $picId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("SELECT picture FROM userprofilepic WHERE picId=:picId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'picId'=>$picId,
        ]);

        return $statement->fetch();
    }

    public static function getProfileData(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
        
        $statement=$conn->prepare("SELECT * FROM users WHERE userId=:userId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'userId'=>$_SESSION['userId'],
        ]);
        return $statement->fetch();
    }

    public static function setProfileData( string $userName, string $userPassword, string $userBirthDate, float $userWeight, float $userHeight){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
        $encryptedPass=password_hash($userPassword, PASSWORD_BCRYPT);

        $statement=$conn->prepare("UPDATE users SET password=:userPassword, username=:userName, birth=:userBirthDate, weight=:userWeight, height=:userHeight WHERE userId=:userId;");
        
        $statement->execute([
            'userId'=>$_SESSION['userId'],
            
            'userName'=>$userName,
            'userPassword'=>$encryptedPass,
            'userBirthDate'=>$userBirthDate,
            'userWeight'=>$userWeight,
            'userHeight'=>$userHeight,
        ]);
       
    }

    public static function setProfileDataWithoutNewPassword( string $userName, string $userBirthDate, float $userWeight, float $userHeight){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("UPDATE users SET username=:userName, birth=:userBirthDate, weight=:userWeight, height=:userHeight WHERE userId=:userId;");
        
        $statement->execute([
            'userId'=>$_SESSION['userId'],
            
            'userName'=>$userName,
            'userBirthDate'=>$userBirthDate,
            'userWeight'=>$userWeight,
            'userHeight'=>$userHeight,
        ]);
       
    }
    public static function setProfileDataWithPofilePicture(string $profPic, string $userName, string $userBirthDate, float $userWeight, float $userHeight){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("INSERT INTO userprofilepic (picture) VALUES (:picture);");
      
        $statement->execute([
            'picture'=>$profPic,
        ]);

        $_SESSION['profPicId'] = $conn->lastInsertId();

        $statement=$conn->prepare("UPDATE users SET username=:userName, birth=:userBirthDate, weight=:userWeight, height=:userHeight,  profilePicId=:profilePicId WHERE userId=:userId;");
        
        $statement->execute([
            'userId'=>$_SESSION['userId'],
            
            'userName'=>$userName,
            'userBirthDate'=>$userBirthDate,
            'userWeight'=>$userWeight,
            'userHeight'=>$userHeight,
            'profilePicId'=>$_SESSION['profPicId'],
        ]);
    }

    public static function setProfileDataWithPofilePictureAndPassword(string $profPic, string $userName, string $userBirthDate, float $userWeight, float $userHeight, string $userPassword){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("INSERT INTO userprofilepic (picture) VALUES (:picture);");
      
        $statement->execute([
            'picture'=>$profPic,
        ]);

        $_SESSION['profPicId'] = $conn->lastInsertId();

        $encryptedPass=password_hash($userPassword, PASSWORD_BCRYPT);

        $statement=$conn->prepare("UPDATE users SET password=:userPassword, username=:userName, birth=:userBirthDate, weight=:userWeight, height=:userHeight,  profilePicId=:profilePicId WHERE userId=:userId;");
        
        $statement->execute([
            'userId'=>$_SESSION['userId'],
            
            'userName'=>$userName,
            'userPassword'=>$encryptedPass,
            'userBirthDate'=>$userBirthDate,
            'userWeight'=>$userWeight,
            'userHeight'=>$userHeight,
            'profilePicId'=>$_SESSION['profPicId'],
        ]);
    }
}