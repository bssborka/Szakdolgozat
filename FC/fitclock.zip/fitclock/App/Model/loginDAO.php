<?php namespace App\Model;

use App\Lib\Database;
use App\Model\DAOCrud;

class loginDAO implements DAOCrud
{
    public static function getUser(string $userEmail, string $password){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("SELECT username,password FROM users WHERE email=:userEmail;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'userEmail'=>$userEmail,
        ]);

        $userLoginData= $statement->fetch();
               
        if($userLoginData!=NULL){
            $encryptedPas=$userLoginData->password;
            if(password_verify($password, $encryptedPas)){
                $statement=$conn->prepare("SELECT profilePicId, userId, username FROM users WHERE email=:userEmail;");
                $statement->setFetchMode(\PDO::FETCH_OBJ);
                $statement->execute([
                    'userEmail'=>$userEmail,
                ]);
                return $statement->fetch();
            }
        }
    }
    
    public static function getProfilePicture(int $picId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("SELECT picture FROM userprofilepic WHERE picId=:picId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'picId'=>$picId,
        ]);

        return $statement->fetch();
    }


    public static function createUser(string $userEmail, string $userName, string $userPassword, string $userBirthDate, int $userSex){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $encryptedPass=password_hash($userPassword, PASSWORD_BCRYPT);
        
        $statement=$conn->prepare("INSERT INTO users (email, username, password, birth, userGenderId) VALUES (:userEmail,:userName,:userPassword,:userBirthDate,:userSex);");
        
        $statement->execute([
            'userEmail'=>$userEmail,
            'userName'=>$userName,
            'userPassword'=>$encryptedPass,
            'userBirthDate'=>$userBirthDate,
            'userSex'=>$userSex,
            
        ]);
        
    }

    public static function userIsRegistered(string $userEmail){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("SELECT userId FROM users WHERE email=:userEmail;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'userEmail'=>$userEmail,
        ]);
        $isThereAUser= $statement->fetch();

        if($isThereAUser==NULL){
            return false;
        }else{
            return true;
        }
    }
    
}