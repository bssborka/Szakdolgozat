<?php namespace App\Model;

use App\Lib\Database;
use App\Model\teamsDAOCrud;

class teamsDAO implements teamsDAOCrud
{
    public static function getProfilePicture(int $picId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("SELECT picture FROM userprofilepic WHERE picId=:picId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'picId'=>$picId,
        ]);

        return $statement->fetch();
    }

    public static function getTeams(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
        //csapatok adatainak lekérése (kép, név, tagok, admin)
        $statement=$conn->prepare("SELECT groups.groupId,groups.groupName,groups.groupAdmin, grouppic.picture, grouptags.userId FROM (groups INNER JOIN grouppic ON groups.groupPicId=grouppic.picId) INNER JOIN grouptags ON grouptags.groupId=groups.groupId WHERE grouptags.userId LIKE :userId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'userId'=>$_SESSION['userId'],
        ]);
        return $statement->fetchAll();
        
    }

    public static function getOneTeam(int $teamId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
       
        $statement=$conn->prepare("SELECT groups.groupAdmin, grouptags.userId, groups.groupName FROM groups INNER JOIN grouptags ON grouptags.groupId=groups.groupId WHERE groups.groupId=:groupId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'groupId'=>$teamId,
        ]);
        return $statement->fetchAll();
        
    }

    public static function getTeamName(int $teamId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
       
        $statement=$conn->prepare("SELECT groupName FROM groups WHERE groupId=:groupId;");
       
        $statement->execute([
            'groupId'=>$teamId,
        ]);
        return $statement->fetch();
        
    }

    public static function createTeam(string $teamName, string $myimage){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        //csapat prof kep feltoltese
        $statement=$conn->prepare("INSERT INTO grouppic (picture) VALUES (:picture);");
      
        $statement->execute([
            'picture'=>$myimage,
        ]);

        //csapat prof kep ID 
        $picId = $conn->lastInsertId();

        //csapat letrehozasa
        $statement=$conn->prepare("INSERT INTO groups (groupName, groupAdmin, groupPicId) VALUES (:groupName,:groupAdmin,:groupPicId);");
        
        $statement->execute([
            'groupName'=>$teamName,
            'groupAdmin'=>$_SESSION['userId'],
            'groupPicId'=>$picId,
        ]);

        //admin beírása tagnak is
        $groupId = $conn->lastInsertId();
        $statement=$conn->prepare("INSERT INTO grouptags (userId, groupId) VALUES (:userId,:groupId);");
        
        $statement->execute([
            'userId'=>$_SESSION['userId'],
            'groupId'=>$groupId,
        ]);

         

    }


    public static function inviteUsers(string $teamUsersEmails, int $teamId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
         //csapat tagjainak feltöltése
         $userEmails= explode(",",$teamUsersEmails);
        
         foreach($userEmails as $email){
            //aktuális csapat tag ID email alapján
            $statement=$conn->prepare("SELECT userId FROM users WHERE email=:email;");
            $statement->setFetchMode(\PDO::FETCH_OBJ);
            $statement->execute([
                'email'=>$email,
            ]);
            $userId= $statement->fetch();
            
            if($userId!=NULL){
                //már felvett tagok
                $statement=$conn->prepare("SELECT userId FROM grouptags WHERE userId=:userId AND groupId=:groupId;");
                $statement->setFetchMode(\PDO::FETCH_OBJ);
                $statement->execute([
                    'userId'=>$userId->userId,
                    'groupId'=>$teamId,
                ]);
                $isThereAUser= $statement->fetch();
                //nem felvett tagok felvétele
                if($isThereAUser==NULL){
                    $statement=$conn->prepare("INSERT INTO grouptags (userId, groupId) VALUES (:userId,:groupId);");
                
                    $statement->execute([
                    'userId'=>$userId->userId,
                    'groupId'=>$teamId,
                    ]);
                }
            }   
        }
    }

    public static function getTeamMembers(int $teamId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
       
        $statement=$conn->prepare("SELECT groups.groupAdmin, users.userId, users.username, users.birth, users.weight, users.height, genders.gender, users.email FROM ((groups INNER JOIN grouptags ON grouptags.groupId=groups.groupId) INNER JOIN users ON users.userId=grouptags.UserId) INNER JOIN genders ON users.userGenderId=genders.genderId WHERE groups.groupId=:groupId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'groupId'=>$teamId,
        ]);
        return $statement->fetchAll();
        
    }
    public static function memberDelete($userId,$groupId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
       
        $statement=$conn->prepare("DELETE FROM grouptags WHERE grouptags.groupId=:groupId AND grouptags.userId=:userId;");
        
        $statement->execute([
            'groupId'=>$groupId,
            'userId'=>$userId
        ]);
    }
}