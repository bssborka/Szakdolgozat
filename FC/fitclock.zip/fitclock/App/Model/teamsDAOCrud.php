<?php namespace App\Model;

    interface teamsDAOCrud
    {
        public static function getProfilePicture(int $picId);
        public static function getTeams();
        public static function getOneTeam(int $teamId);
        public static function createTeam(string $teamName, string $myimage);
        public static function inviteUsers(string $teamUsersEmails, int $teamId);
        public static function getTeamMembers(int $teamId);
        public static function getTeamName(int $teamId);
        public static function memberDelete($userId,$groupId);
    }
?>