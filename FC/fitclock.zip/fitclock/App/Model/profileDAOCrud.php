<?php namespace App\Model;

    interface profileDAOCrud
    {
        public static function getProfilePicture(int $picId);
        public static function getProfileData();
        public static function setProfileData( string $userName, string $userPassword, string $userBirthDate, float $userWeight, float $userHeight);
        public static function setProfileDataWithoutNewPassword( string $userName, string $userBirthDate, float $userWeight, float $userHeight);
        public static function setProfileDataWithPofilePicture(string $profPic, string $userName, string $userBirthDate, float $userWeight, float $userHeight);
        public static function setProfileDataWithPofilePictureAndPassword(string $profPic, string $userName, string $userBirthDate, float $userWeight, float $userHeight, string $userPassword);
    }
?>