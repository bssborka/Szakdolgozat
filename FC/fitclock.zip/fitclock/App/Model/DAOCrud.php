<?php namespace App\Model;

    interface DAOCrud
    {
       public static function getUser(string $userEmail, string $password);
       public static function getProfilePicture(int $picId);
       public static function createUser(string $userEmail, string $userName, string $userPassword, string $userBirthDate, int $userSex);
       public static function userIsRegistered(string $userEmail);
    }
?>