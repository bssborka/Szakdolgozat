<?php namespace App\Model;

    interface ratingDAOCrud
    {
        public static function getProfilePicture(int $picId);
        public static function decideIfAlreadySent();
        public static function setRating(int $graphics, int $functions, int $exercises, int $groups, string $comments);
    }
?>