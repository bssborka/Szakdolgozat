<?php namespace App\Model;

use App\Lib\Database;
use App\Model\ratingDAOCrud;

class ratingDAO implements ratingDAOCrud
{
    public static function getProfilePicture(int $picId){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("SELECT picture FROM userprofilepic WHERE picId=:picId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'picId'=>$picId,
        ]);

        return $statement->fetch();
    }
    
    public static function decideIfAlreadySent(){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();

        $statement=$conn->prepare("SELECT reviewId FROM review WHERE userId=:userId;");
        $statement->setFetchMode(\PDO::FETCH_OBJ);
        $statement->execute([
            'userId'=>$_SESSION['userId'],
        ]);

        return $statement->fetch();
    }

    public static function setRating(int $graphics, int $functions, int $exercises, int $groups, string $comments){
        $dbObj = new Database();
        $conn = $dbObj->getConnection();
        
        $statement=$conn->prepare("INSERT INTO review (graphics, functions, exercises, groups, comments, userId) VALUES(:graphics,:functions,:exercises,:groups,:comments,:userId);");
        
        $statement->execute([
            'userId'=>$_SESSION['userId'],
            'graphics'=>$graphics,
            'functions'=>$functions,
            'exercises'=>$exercises,
            'groups'=>$groups,
            'comments'=>$comments,
        ]);
       
    }

}