
function openFormInvite() {
    document.getElementById("invitePopup").style.display = "block";
    document.getElementById("popupContainerInvite").style.display = "block";
}
  
function closeFormInvite() {
    document.getElementById("invitePopup").style.display = "none";
    document.getElementById("popupContainerInvite").style.display = "none";
}

function openFormMembers() {
    document.getElementById("membersPopup").style.display = "block";
    document.getElementById("popupContainerMembers").style.display = "block";
}
  
function closeFormMembers() {
    document.getElementById("membersPopup").style.display = "none";
    document.getElementById("popupContainerMembers").style.display = "none";
}