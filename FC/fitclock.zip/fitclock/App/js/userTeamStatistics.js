function generateAgeDiagram(){
    //DATA FROM TWIG
    const membersData = JSON.parse(document.getElementById('membersData').value);
    const userName = JSON.parse(document.getElementById('userName').value);

    //labelek, és adatok dinamikus elkészítése
    var datanumbers = [];
    var labels = [];
    
    for (var i = 0; i < membersData.length; i++) 
    {
        if(membersData[i].groupAdmin!=membersData[i].userId){
            if(membersData[i].username==userName.username){
                var birthdate = new Date(membersData[i].birth);
                var ageInMillis = Date.now() - birthdate.getTime();
                var ageInYears = ageInMillis / (1000 * 60 * 60 * 24 * 365.25);
    
                var age = Math.floor(ageInYears);
    
                datanumbers.push(age);
                labels.push(membersData[i].username);
            }
        }
    }
    
    for (var i = 0; i < membersData.length; i++) 
    {
        if(membersData[i].groupAdmin!=membersData[i].userId){
            if(membersData[i].username!=userName.username){
                var birthdate = new Date(membersData[i].birth);
                var ageInMillis = Date.now() - birthdate.getTime();
                var ageInYears = ageInMillis / (1000 * 60 * 60 * 24 * 365.25);

                var age = Math.floor(ageInYears);

                datanumbers.push(age);
                labels.push(membersData[i].username);
            }
        }
    }

    //Canvas tisztítása
    document.getElementById("chartContainer").innerHTML = '&nbsp;';
    document.getElementById("chartContainer").innerHTML = '<canvas id="myChart"></canvas>';
    var ctx = document.getElementById("myChart").getContext("2d");
    var canvas = document.getElementById('myChart');
    canvas.height = 100;
    
  var data = {
    labels: labels,
    datasets: [
        {
            data:datanumbers,
            backgroundColor: '#0099ff'
            
        }
    ]
};

//Set the chart properties
var options = {
    legend: {display: false},
    title: {
        display: true,
        text: "A csapattagok életkora"
      },
    scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
    }
};

//Create the chart

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {type: 'bar',data: data,options: options});
myChart.update();
}

function generateWeightDiagram(){
//DATA FROM TWIG
const membersData = JSON.parse(document.getElementById('membersData').value);
const userName = JSON.parse(document.getElementById('userName').value);

//labelek, és adatok dinamikus elkészítése
var datanumbers = [];
var labels = [];

for (var i = 0; i < membersData.length; i++) 
{
    if(membersData[i].groupAdmin!=membersData[i].userId)
    {
        if(membersData[i].username==userName.username)
        {
                labels.push(membersData[i].username);
                datanumbers.push(membersData[i].weight);
        }
    }
}

for (var i = 0; i < membersData.length; i++) 
{
    if(membersData[i].groupAdmin!=membersData[i].userId){
        if(membersData[i].username!=userName.username)
        {
                labels.push(membersData[i].username);
                datanumbers.push(membersData[i].weight);
        }
    }
}

//Canvas tisztítása
document.getElementById("chartContainer").innerHTML = '&nbsp;';
document.getElementById("chartContainer").innerHTML = '<canvas id="myChart"></canvas>';
var ctx = document.getElementById("myChart").getContext("2d");
var canvas = document.getElementById('myChart');
canvas.height = 100;

var data = {
labels: labels,
datasets: [
    {
        data:datanumbers,
        backgroundColor: '#0099ff'
        
    }
]
};

//Set the chart properties
var options = {
legend: {display: false},
title: {
    display: true,
    text: "A csapattagok súlya, kilógrammban"
  },
scales: {
    yAxes: [{
        ticks: {
            beginAtZero: true
        }
    }]
}
};

//Create the chart

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {type: 'bar',data: data,options: options});
myChart.update();
}

function generateHeightDiagram(){
//DATA FROM TWIG
const membersData = JSON.parse(document.getElementById('membersData').value);
const userName = JSON.parse(document.getElementById('userName').value);

//labelek, és adatok dinamikus elkészítése
var datanumbers = [];
var labels = [];

for (var i = 0; i < membersData.length; i++) 
{
    if(membersData[i].groupAdmin!=membersData[i].userId)
    {
        if(membersData[i].username==userName.username)
        {
            labels.push(membersData[i].username);
            datanumbers.push(membersData[i].height);
        }
    }
}


for (var i = 0; i < membersData.length; i++) 
{
    if(membersData[i].groupAdmin!=membersData[i].userId){
        if(membersData[i].username!=userName.username)
        {
            labels.push(membersData[i].username);
            datanumbers.push(membersData[i].height);
        }
    }
}

//Canvas tisztítása
document.getElementById("chartContainer").innerHTML = '&nbsp;';
document.getElementById("chartContainer").innerHTML = '<canvas id="myChart"></canvas>';
var ctx = document.getElementById("myChart").getContext("2d");
var canvas = document.getElementById('myChart');
canvas.height = 100;

var data = {
labels: labels,
datasets: [
    {
        data:datanumbers,
        backgroundColor: '#0099ff'
        
    }
]
};

//Set the chart properties
var options = {
legend: {display: false},
title: {
    display: true,
    text: "A csapattagok magassága, centiméterben"
  },
scales: {
    yAxes: [{
        ticks: {
            beginAtZero: true
        }
    }]
}
};
//Create the chart

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {type: 'bar',data: data,options: options});
myChart.update();
}

function generateBMIDiagram(){
//DATA FROM TWIG
const membersData = JSON.parse(document.getElementById('membersData').value);
const userName = JSON.parse(document.getElementById('userName').value);

//BMI számoláshoz tömb generálása

var finalBMIOfMembers = []; 

for(var i=0; i<membersData.length;i++){
    finalBMIOfMembers.push(0)
}

//labelek, és adatok dinamikus elkészítése és BMI számolás
var datanumbers = [];
var labels = [];

for (var i = 0; i < membersData.length; i++) 
{
    if(membersData[i].groupAdmin!=membersData[i].userId)
    {
        if(membersData[i].username==userName.username)
        {
            if(membersData[i].weight==""){
                finalBMIOfMembers[i]=0;
            }
            else if(membersData[i].height==""){
                finalBMIOfMembers[i]=0;
            }
            else{
                finalBMIOfMembers[i]= membersData[i].weight / ((membersData[i].height/100)*(membersData[i].height/100));
            }
            
            labels.push(membersData[i].username);
            datanumbers.push(Math.round(finalBMIOfMembers[i]));
        }
    }
}

for (var i = 0; i < membersData.length; i++) 
{
    if(membersData[i].groupAdmin!=membersData[i].userId){
        if(membersData[i].username!=userName.username)
        {
            if(membersData[i].weight==""){
                finalBMIOfMembers[i]=0;
            }
            else if(membersData[i].height==""){
                finalBMIOfMembers[i]=0;
            }
            else{
                finalBMIOfMembers[i]= membersData[i].weight / ((membersData[i].height/100)*(membersData[i].height/100));
            }
            
            labels.push(membersData[i].username);
            datanumbers.push(Math.round(finalBMIOfMembers[i]));
        }
    }
}

//Canvas tisztítása
document.getElementById("chartContainer").innerHTML = '&nbsp;';
document.getElementById("chartContainer").innerHTML = '<canvas id="myChart"></canvas>';
var ctx = document.getElementById("myChart").getContext("2d");
var canvas = document.getElementById('myChart');
canvas.height = 100;

var data = {
labels: labels,
datasets: [
    {
        data:datanumbers,
        backgroundColor: '#0099ff'
        
    }
]
};

//Set the chart properties
var options = {
legend: {display: false},
title: {
    display: true,
    text: "A csapattagok BMI szintje"
  },
scales: {
    yAxes: [{
        ticks: {
            beginAtZero: true
        }
    }]
}
};
//Create the chart

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {type: 'bar',data: data,options: options});
myChart.update();

}
