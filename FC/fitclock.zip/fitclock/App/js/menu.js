function myFunction() {
    var x = document.getElementById("linknav");
    if (x.className === "links") {
      x.className += "  responsive";
    } else {
      x.className = "links";
    }
  }


