
function generateDiagramCalorie(){
    //DATA FROM TWIG
    const calories = JSON.parse(document.getElementById('caloriesOnTheWeek').value);
    
    for (var i = 0; i < calories.length; i++) {
        calories[i]=Math.round(calories[i]);
    }

    //Canvas tisztítása
    document.getElementById("chartContainer").innerHTML = '&nbsp;';
    document.getElementById("chartContainer").innerHTML = '<canvas id="myChart"></canvas>';
    var ctx = document.getElementById("myChart").getContext("2d");
    var canvas = document.getElementById('myChart');
    canvas.height = 120;
    
  // Define the data
  var data = {
    labels: ['HÉTFŐ', 'KEDD', 'SZERDA', 'CSÜTÖRTÖK', 'PÉNTEK','SZOMBAT','VASÁRNAP'],
    datasets: [
        {
            data: [calories[1], calories[2], calories[3], calories[4], calories[5],calories[6],calories[0]],
            backgroundColor: '#0099ff'
            
        }
    ]
};

// Set the chart properties
var options = {
    legend: {display: false},
    title: {
        display: true,
        text: "Kalória égetés a héten"
      },
    scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
    }
};

// Create the chart

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {type: 'bar',data: data,options: options});
myChart.update();
}

function generateDiagramTimePerWeek(){
    //DATA FROM TWIG
    const times = JSON.parse(document.getElementById('timesOfWeek').value);
        
    for (let i = 0; i < times.length; i++) {
        times[i]=Math.round(times[i]);
    }

    //Canvas tisztítása
    document.getElementById("chartContainer").innerHTML = '&nbsp;';
    document.getElementById("chartContainer").innerHTML = '<canvas id="myChart"></canvas>';
    var ctx = document.getElementById("myChart").getContext("2d");
    var canvas = document.getElementById('myChart');
    canvas.height = 120;
    // Define the data
    var data = {
      labels: ['HÉTFŐ', 'KEDD', 'SZERDA', 'CSÜTÖRTÖK', 'PÉNTEK','SZOMBAT','VASÁRNAP'],
      datasets: [
          {
            data: [times[1], times[2], times[3], times[4], times[5],times[6],times[0]],
            backgroundColor: '#0099ff'
          }
      ]
  };
  
  // Set the chart properties
  var options = {
    legend: {display: false},
    title: {
        display: true,
        text: "Edzéssel töltött idő a héten, másodpercben"
      },
    scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
    }
};
  
  // Create the chart

  var ctx = document.getElementById('myChart').getContext('2d');
  var myChart = new Chart(ctx, {type: 'bar',data: data,options: options});
  myChart.update();
}

function generateDiagramIntensity(){
    //DATA FROM TWIG
    const intensities = JSON.parse(document.getElementById('intensitiesOfWeek').value);
    
    
    //Canvas tisztítása
    document.getElementById("chartContainer").innerHTML = '&nbsp;';
    document.getElementById("chartContainer").innerHTML = '<canvas id="myChart"></canvas>';
    var ctx = document.getElementById("myChart").getContext("2d");
    var canvas = document.getElementById('myChart');
    canvas.height = 120;
    
  // Define the data
  var data = {
    labels: ['HÉTFŐ', 'KEDD', 'SZERDA', 'CSÜTÖRTÖK', 'PÉNTEK','SZOMBAT','VASÁRNAP'],
    datasets: [
        {
            data: [intensities[1], intensities[2], intensities[3], intensities[4], intensities[5],intensities[6],intensities[0]],
            backgroundColor: '#0099ff'
            
        }
    ]
};

// Set the chart properties
var options = {
    legend: {display: false},
    title: {
        display: true,
        text: "Edzések intenziátsának az átlaga a héten"
      },
    scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
    }
};

// Create the chart

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {type: 'bar',data: data,options: options});
myChart.update();
}

function generateDiagramMuscleGroupe(){
    //DATA FROM TWIG
    const MuscleUsage = JSON.parse(document.getElementById('muscleUsageOfWeek').value);
    const muscleGroupsData = JSON.parse(document.getElementById('muscleGroupsData').value);

    //labelek, és adatok dinamikus elkészítése
    var labels = [];
    var data = [];
    for (var i = 0; i < MuscleUsage.length; i++) 
    {
        labels.push(muscleGroupsData[i].muscleGroupName);
        data.push(MuscleUsage[i]);
    }

    //Canvas tisztítása
    document.getElementById("chartContainer").innerHTML = '&nbsp;';
    document.getElementById("chartContainer").innerHTML = '<canvas id="myChart"></canvas>';
    var ctx = document.getElementById("myChart").getContext("2d");
    var canvas = document.getElementById('myChart');
    canvas.height = 120;
    
  //Define the data
  var data = {
    labels: labels,
    datasets: [
        {
            data:data,
            backgroundColor: '#0099ff'
            
        }
    ]
};

//Set the chart properties
var options = {
    legend: {display: false},
    title: {
        display: true,
        text: "Az izmok megmozgatása a héten, másodpercben"
      },
    scales: {
        yAxes: [{
            ticks: {
                beginAtZero: true
            }
        }]
    }
};

//Create the chart

var ctx = document.getElementById('myChart').getContext('2d');
var myChart = new Chart(ctx, {type: 'bar',data: data,options: options});
myChart.update();
}